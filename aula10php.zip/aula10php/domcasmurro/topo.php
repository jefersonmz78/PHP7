<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="view/css/estilo.css"/>
        <link rel="stylesheet" type="text/css" href="view/css/bootstrap.min.css"/>
        <title>Dom Casmurro</title>
    </head>
    <body>
        <section class="container-fluid">
            <section class="col-xs-12">
                <header>
                    <h1>Livraria Dom Casmurro</h1>
                </header>
            </section>
            <section class="col-xs-12">
                <nav>
                    <ul class="nav nav-pills nav-justified">
                        <li><a href="index.php">HOME</a></li>
                        <li><a href="livros.php">LIVROS</a></li>
                        <li><a href="ebooks.php">eBOOKS</a></li>
                        <li><a href="contato.php">CONTATO</a></li>
                        <li><a href="cadastrar.php">CADASTRO</a></li>
                    </ul>
                </nav>
            </section>   

