 <!--
  * CRUD - CREATE - READER - UPDATE - DELETE 
  * As 4 opera��es b�sicas que qualquer Sistema deve executar.
  * 
  * 02 - READER - select
 
   //Programa��o para que o PHP busque os dados na tabela usu�rio.
   -->
<?php require_once 'DAO.php';?>

<a href="../cadastrar.php">Adicionar Novo Usu�rio</a>

<table border='0' width='100%'>
    <tr>
        <th>ID</th>
        <th>Nome</th>
        <th>Celular</th>
        <th>E-mail</th>    
    </tr>
    
    <?php
       try{
           $sql="SELECT * FROM usuario";
           $sql=$pdo->query($sql);
           
           if($sql->rowCount() >0){
                echo "Tem usu�rio cadastrado<br/><br/>";
                
                foreach ($sql->fetchAll() as $usuario){
                    echo '<tr>';
                        echo '<td>'.$usuario['id'].'</td>';
                        echo '<td>'.$usuario['nome'].'</td>';
                        echo '<td>'.$usuario['celular'].'</td>';
                        echo '<td>'.$usuario['email'].'</td>'; 
                        echo '<td><a href="editar.php?id='.$usuario['id'].'">Editar</a></td>';
                        echo '<td><a href="excluir.php?id='.$usuario['id'].'">Excluir</a></td>';                
                    echo '</tr>';
                }
           }else{
               echo "N�o h� nenhum usu�rio cadastro";
           }
           
       } catch (PDOException $ex) {
           echo "Falhou: ".$ex->getMessage();

       }
    
    ?>
</table>