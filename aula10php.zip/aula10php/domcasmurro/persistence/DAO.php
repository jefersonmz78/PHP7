<?php
//Programa��o para conectar ao SGBD - MySQL Server
/*
 * host   = endereço do servidor de DB = localhost
 * dbname = nome do banco de dados criado no SGBD 
 * login do usuário = "root
 * senha do usuário = ""
 * */
 
//$pdo = new PDO("mysql:host=localhost;dbname=domcasmurro","root","" )
 
//Declando as vari�veis de conex�o ao banco de dados
$dbserver = "mysql:host=localhost;dbname=domcasmurro"; 
$dbadmin  = "root";
$dbsenha  = "";

//Algoritmo do try-catch-finally
try{
     $pdo = new PDO($dbserver,$dbadmin,$dbsenha);
     
  //   echo "Conexao estabelecida com sucesso!";
     
} catch (PDOException $ex) {
    
     echo "Falhou: ".$ex->getMessage();
}
  finally{
      echo "Cadastro feito com sucesso!";
  }


?>
