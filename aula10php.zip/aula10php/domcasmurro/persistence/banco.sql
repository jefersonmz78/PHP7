--Logar no MySQLServer como administrador
mysql -u root -p

--Verificando os Bancos de dados existente
show databases;

--Excluir o banco dados, caso exista
DROP DATABASE IF EXISTS domcasmurro;

--Criar o bando de dados domcasmurro
CREATE DATABASE domcasmurro;

--Verificando se criou o banco de dados
SHOW DATABASES;

--Abrir a conexão com o banco de dados
USE domcasmurro;

--Verificando sem alguma tabela
SHOW TABLES;

--Criando a tabela de cadastro de usuário.
CREATE TABLE usuario(
id       INT AUTO_INCREMENT PRIMARY KEY,
nome     VARCHAR(60)NOT NULL,
celular  VARCHAR(60)NOT NULL,
email    VARCHAR(60)NOT NULL,
endereco VARCHAR(80)NOT NULL
)COMMENT = "Tabela de cadastro de usuarios";

--Descrição da tabela criada
DESC usuario;

--Inserindo um cadastro
INSERT INTO usuario values(
null,
'Carlos Alberto',
'21987456321',
'carlos@gmail.com',
'Rua Paris, Bonsucesso');

--Verificando os registros de uma tabela
SELECT * FROM usuario;


