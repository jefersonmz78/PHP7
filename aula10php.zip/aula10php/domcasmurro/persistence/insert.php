<?php
 /*
  * CRUD - CREATE - READER - UPDATE - DELETE 
  * As 4 opera��es b�sicas que qualquer Sistema deve executar.
  * 
  * 01 - CREATE - insert
  */
  // require_once 'persistence/DAO.php';
   
   //Programa��o para que o PHP encaminhe os dados do formulario para o DB
   if(isset($_POST['nome']) && empty($_POST['nome'] == false)){
       $nome     =  addslashes($_POST['nome']);
       $celular  =  addslashes($_POST['celular']);
       $email    =  addslashes($_POST['email']);
       $endereco =  addslashes($_POST['endereco']);
       
       //Query para para gravar os dados no DB
       $sql = "INSERT INTO usuario SET nome = '$nome',celular = '$celular',email = '$email',endereco = '$endereco'"; 
       $pdo->query($sql);
       
       //header("Location: index.php");       
   }else{
     // header("Location: cadastrar.php"); 
   }
?>