<?php
   require_once 'topo.php';
   require_once 'persistence/DAO.php';
 
   //Programa��o para que o PHP encaminhe os dados do formulário para o DB
   if(isset($_POST['nome']) && empty($_POST['nome'] == false)){
       $nome     =  addslashes($_POST['nome']);
       $celular  =  addslashes($_POST['celular']);
       $email    =  addslashes($_POST['email']);
       $endereco =  addslashes($_POST['endereco']);
       
       //Query para para gravar os dados no DB
       $sql = "INSERT INTO usuario SET nome = '$nome',celular = '$celular',email = '$email',endereco = '$endereco'"; 
       $pdo->query($sql);
       
       //header("Location: index.php");       
   }else{
     // header("Location: cadastrar.php"); 
   }
  
   //action="persistence/insert.php"

?>
    <section class="col-xs-12">
        <h3>Cadastro</h3>
        <form  method="POST" name="usuario" >
                Nome:<br/>
                <input type="text" name="nome"><br/><br/>
                Celular:<br/>
                <input type="text" name="celular"><br/><br/>
                E-mail:<br/>
                <input type="text" name="email"><br/><br/>
                Endere�o:<br/>
                <input type="text" name="endereco"><br/><br/>
                
                <input type="submit">
            </form>        
    </section>
<?php
   require_once 'rodape.php';
?>

