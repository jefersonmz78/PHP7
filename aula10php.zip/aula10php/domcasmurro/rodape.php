            <section class="col-xs-12">
                <footer>
                    <h1>Conteúdodo Rodapé.</h1>
                </footer>
            </section>
        </section>
    </body>
   <script src="view/js/bootstrap.min.js" type="text/javascript"></script>
   <script src="view/js/jquery-3.2.1.js" type="text/javascript"></script>
</html>
