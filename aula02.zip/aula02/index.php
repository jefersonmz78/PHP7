<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
              //Comentário de linha
        
               /*
                * Comentário de bloco.
                */
            /*
              Tag para código de PHP
             * 
             * <? php 
             *    Aqui ficará todo o código do PHP
             * ?>             
             */
        // comando valor ;
        echo "Olá Mundo";
        echo "<br/><br/>";
        
        /*
         * VARIÁVEL - é um recurso para reservar um espaço na memória
         * onde você poderá armazenar um determinado TIPO DE INFORMAÇÃO (dado)
         * 
         * TIPOS DE DADOS:
         * númericos, booleanos, caracterer, coleções.
         */
         
        $x    = 1;          //variável tipo inteiro
        $y    = 2.2;       // variável tipo ponto flutuante
        $w    = "ESTUDEM"; // variável tipo caracter.
        $sim  = TRUE;      // variável tipo booleano.
        $nulo = NULL;     //variável tipo nulo.
        
        $h = "STRING = texto, um conjunto de caracteres";
        $r = "CARACTER = exclusivamante uma letra - M ou F";
        
         //  echo $x;
        //1-concatenação no PHP string . variável
         //2-concatenação no PHP string , variável
        echo "O valor INTEGER (inteiro)atribuido a variável X eh igual: ".$x;
        echo "<br/>";
        echo "O valor DOUBLE (ponto flutuante) atribuido a variável Y eh igual: ",$y;
        echo "<br/>";
        echo "O valor STRING (caracter) atribuido a variável W eh igual: ".$w;
        echo "<br/>";

        
        //Diferença de "ASPAS" e 'APÓSTROFO'
        echo "testando o delimitador de string com ASPAS";
        echo "<br/>";
        echo 'testando o delimitador de string com APÓSTROFO';
        echo "<br/>";
        echo "testando o delimitador de string com ASPAS -> $x";
        echo "<br/>";
        echo 'testando o delimitador de string com APÓSTROFO -> $x';
        echo "<br/>";
        echo ' "testando o delimitador de string com ASPAS" ';
        echo "<br/>";
        
        /*CONSTANTE
         * É um valor que não irá variar durante a execução.
         * Ex: salário mínimo: R$ 950,00
         * Ex: adicional noturno, acréscimo de 20% do salário.
         * sintaxe:
         * define("nome da constante", "valor da constante);
        */
   
         define("salario", "950.00");
         echo "O salário mínimo eh de R$ ".salario;
         echo "<br/>";
                
         //OPERADORES
         
         echo "<h1>Operadores Aritméticos</h1>";
         $a = 10;
         $b = 5;
         
         $soma      = $a + $b;
         $diferenca = $a - $b;
         $produto   = $a * $b;
         $quociente = $a / $b;
         
         echo "<br>";echo "<br>";
         
         echo "Adição de duas variáveis: ".$soma;           echo "<br/>";echo "<br/>";
         echo "Subtração de duas variáveis: ".$diferenca;   echo "<br/>";echo "<br/>";
         echo "Multiplicação de duas variáveis: ".$produto; echo "<br/>";echo "<br/>";
         echo "Divisão de duas variáveis: ".$quociente;     echo "<br/>";echo "<br/>";
         
         
         echo "<h1>Operadores de String</h1>";
         $nome      = "Epaminondas";
         $sobrenome = "Mendes";
         
         echo $nome." ".$sobrenome;   echo "<br/>";echo "<br/>";
         
          echo "<h1>Operadores de Comparação</h1>";
          
          //atribuição de valor
          $c = 1;
          $d = 2;
          
          //comparação - igualdade
          echo $c == $d; echo "<br/>";echo "<br/>"; //igual a
          echo $c != $d; echo "<br/>";echo "<br/>"; // diferente de
          echo $c <  $d; echo "<br/>";echo "<br/>"; // menor que
          echo $c >  $d; echo "<br/>";echo "<br/>"; // maior que
          echo $c <=  $d; echo "<br/>";echo "<br/>"; // menor ou iigual a
          echo $c >=  $d; echo "<br/>";echo "<br/>"; // maior que igual a
          
           
        ?>
    </body>
</html>
