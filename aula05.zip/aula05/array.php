<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
       <?php
     /*
       $a = 0;
       $b = 1;
       $a=$b;
      * 
      * Array - É uma variável para armazenar lista de valores do mesmo tipo.
      *   array é uma variável multi-valorado.
      * 
      * sintaxe:
      * $nome_do_variavel[indice]=valores;
      * $variável = array (valor01, valor01, valo03, etc);
      */
        //array de frutas - com valor implicito - automatico - começa no 0
        $frutas = array("banana", "pêra", "maçã");      
        
        echo $frutas[1];
        
        echo "<br/><br/>";
        //array de frutas - com valores explicito.
        $frute = array(1=>"melancia", 2=>"abacaxi", 3=>"tomate");
        
        echo $frute[2];
        echo "<br/><br/>";
        
        //Matriz
        /*sintaxe:
         *
           $a[0][0] = "valo01";
           $a[0][1] = "valo02";
           
          echo $a[0][0];
        */
        
        $cor=array(0=>array(0=>"Ciano",1=>"Preto"));
        echo $cor[0][1];
        
        ?>
    </body>    
 

