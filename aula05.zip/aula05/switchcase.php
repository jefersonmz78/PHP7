<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        /*
         * sintaxe do Switch Case
         * 
         * declarar variável inicial
         *  $i = x;
         *  switch ($i){
         *    case 0:
         *     echo "mensagem";
         *    break;
         *    case 1:
         *     echo "mensagem";
         *    break;
         *    case 2:
         *     echo "mensagem";
         *    break;
         * default:
         *   echo "mensagem";
         * } 
         */
        echo "<br/><br/>";
        echo "Exemplo-01<br/><br/>";
          
        //Declarando variável inicial do switch case
           $i = 0;
          
        if ($i == 0) {
          echo "i equals 0";
        } elseif ($i == 1) {
          echo "i equals 1";
        } elseif ($i == 2) {
          echo "i equals 2";
        }
        
        echo "<br/><br/>";
        echo "Exemplo-02<br/><br/>";
        switch ($i) {
        case 0:
          echo "i equals 0";
        break;
        case 1:
          echo "i equals 1";
        break;
        case 2:
           echo "i equals 2";
        break;
      }
      
       echo "<br/><br/>";
       echo "Exemplo-03<br/><br/>";
       /*
        * Crie um algoritmo usando o SWITCH CASE para imprimir
        * os conceitos dos alunos do SENAC;
        * 
        * ÓTIMO        - O - 9 a 10
        * BOM          - B - 7 a 8
        * SUFICIENTE   - S - 5 a 6
        * INSUFICIENTE - I - 1 a 4
        * 
        * Caso o aluno receba um dos conceitos,
        * imprima o resultado dos conceitos. 
        */
       
       //variável inicial
       $conceito = 1;
       
        switch($conceito){
            case($conceito>=9):
                echo "O - Ótimo";
            break;
            case($conceito>=7 && $conceito<=8):
                echo "B - Bom";
            break;
            case($conceito >=5 && $conceito <= 6):
                echo "S - Suficiente";
            break;
            default:
              echo "I - Insuficiente";
            
        }
        

        ?>
    </body>
</html>
