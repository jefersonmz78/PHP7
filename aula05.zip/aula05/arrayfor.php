<?php
/*
 * Juntando tudo - ARRAY COM FOR
 */
echo "<br/><br/>";

$frutas = array(
    'maçã',
    'banana',
    'melancia',
    'melão',
    'abacaxi',
    'laranja'
);

for($posicao = 0; $posicao < count($frutas); $posicao++){
    echo "A fruta na posição: " . $posicao . "e" . $frutas[$posicao] . "<br/>";
}

echo "<br/><br/>";

/*
 * Crie o mesmo algoritmo do exercíco anterior mas com uma
 * lista de alunos presente na sala de aula.
 */

