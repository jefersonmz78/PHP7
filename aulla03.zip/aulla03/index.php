<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="css/estilo.css" />
        <title>Operadores</title>
    </head>
    <body>
        <section class="container">
            <?php
                echo "<h3>Operadores de incremento e deremento</h1>";
                
                $e=$f=3; //valor = 3
                $g=$e++; //incremento +1  = 4
                $h=$f--;//deremento - diminiu um valor, a variável $f passou a ter -1
                        
                echo $e;
                echo "<br/>";
                echo $f;
                echo "<br/>";
                echo "<br/>";
                
                echo "<h3>Operadores Lógicos</h3>";
                $i = 1;
                $j = 2;
                
                if(2>3 and 4>3){ #e
                    echo "correto";
                }
                
                if(3>2 && 5>4){ #e
                    echo "correto";
                }
                
                echo "<br/>";
                echo "<br/>";
                
                if(3>2 or 5>6){ #ou
                    echo "correto";
                }
                
                echo "<br/>";
                echo "<br/>";
                
                if(3>2 || 5>6){ #ou
                    echo "correto";
                }
                
                echo "<br/>";
                echo "<br/>";
                
                if(3==4){ #igual
                    echo "correto";
                }
                
                echo "<br/>";
                echo "<br/>";
                
                if(3 != 4){ #diferente
                    echo "correto";
                }
                
              ?>
        </section>
    </body>
</html>
