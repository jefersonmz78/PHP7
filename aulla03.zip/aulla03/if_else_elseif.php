<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="css/estilo.css" />
        <title>IF ELSE ELSEIF</title>
    </head>
    <body>
        <section class="container">
            <?php
         
             /*
              * Fluxo condicional sequencial, irá imprimir a mensagem do 
              * "VERDADEIRO", "VERDADEIRO", "FALSO".
              * 
              * sintaxe IF ELSE ELSEIF;
              * if(condicional){
              *     echo "verdadeiro";
              * }elseif(condicional){
              *     echo "verdaderio";
              * }else{
              *      echo "falso";
              *  }
              * 
              */
                //Excemplo 01
                //
                //Entrada de dados - declarar variáveis
            
                   $nota01 = 5;
                   $nota02 = 5;
                   $nota03 = 10;
                   $nota04 = 10;
                   $media  = ($nota01+$nota02+$nota03+$nota04)/4;
                   
                   /*
                    * media >= 7 => APROVADO
                    * media >=5 && MEDIA<7 => RECUPERAÇÃO PARALELA
                    * media < 4 => REPROVADO
                    * && -> e 
                    * || -> ou
                    */
                   
                   //Processamento
                   if($media>=7){
                       echo "APROVADO";
                   }elseif($media>=5 && $media<7){
                       echo "RECUPERAÇÃO PARALELA";
                   }else{
                       echo "REPROVADO";
                   }
                   
                   echo "<br/>";
                   echo "<br/>";
                   
                   //Exemplo 02
                   //Processamento
                   if($media>=7){
                       echo "APROVADO";
                   }elseif($media>=5 && $media<7){
                       echo "RECUPERAÇÃO PARALELA";
                   }elseif($media>=4 && $media<5){
                       echo "RECUPERAÇÃO";
                   }else{
                       echo "REPROVADO";
                   }
                   
                   echo "<br/>";
                   echo "<br/>";
                   
                   //Exemplo 03
                   /*
                    * ÓTIMO        - O - 9 a 10
                    * BOM          - B - 7 a 8.9
                    * SUFICIENTE   - S - 6 a 6.9
                    * INSUFICIENTE - I - 0 a 5.9
                    */
                   $nota = 7;
                   
                   //Processamento
                   if($nota>9){
                       echo "CONCEITO - O - ÓTIMO";
                   }elseif ($nota>=7 && $nota<9) {
                       echo "CONCEITO - B - BOM";
                   }elseif($nota>= 6 && $nota<7){
                       echo "CONCEITO - S - SUFICIENTE";
                   }else{
                       echo "CONCEITO - I - INSUFICIENTE";
                   }
              ?>
        </section>
    </body>
</html>

