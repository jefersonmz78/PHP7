<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="css/estilo.css" />
        <title>IF</title>
    </head>
    <body>
        <section class="container">
            <?php
               /*
                * IF - É um condicional para tomada de decisão.
                * É uma operação lógica (boolean) VERDADEIRO ou FALSO
                * 
                * Fluxo (desvio) condicional simples, irá imprimir apenas a mensagem do VERDADEIRO.
                * 
                * Sintaxe if;
                * if (condição){
                *     echo verdadeiro ou falso(vazio).
                * } 
                */ 
            //Exemplo 01
            
            //Declarando variáveis
            $nota01 = 8;
            $nota02 = 7;
            $media = ($nota01+ $nota02)/2;
            
            //Processamento
            if($media>=7){
                //Saída de dados
                echo "APROVADO";
                }          
               
                //Exemplo 02
                
                //Declarando variáveis
                $funcionario = 880;
                $inss        = 0.11;
                
                if($funcionario<800){
                    echo "O desconto no salário será: ".$funcionario * 0.11;
                }
                
              ?>
        </section>
    </body>
</html>
