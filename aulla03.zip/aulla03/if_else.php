<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="css/estilo.css" />
        <title>IF ELSE</title>
    </head>
    <body>
        <section class="container">
            <?php
              /*
               * IF ELSE (composto)
               * 
               *Fuxo (desvio) condidicional composto, irá imprimir a mensagem do VERDADEIRO ou FALSO.
               * 
               * sintaxe IF ELSE:
               * if(condição){
               *    echo verdadeiro;
               * }else{
               *    echo falso;
               * }
               */
            
            //Exemplo 01
            
            //Declarando variáveis
            $nota01 = 8;
            $nota02 = 7;
            $media = ($nota01+ $nota02)/2;
            
            //Processamento
            if($media>=7){
                    //Saída de dados
                  echo "APROVADO";
                }else{
                   //Saída de dados
                    echo "REPROVADO";
                }
            
                
                echo "<br/>";
                 echo "<br/>";
               //Exemplo 02
                
                //Declarando variáveis
                $funcionario = 880;
                $inss        = 0.11;
                
                //Processamento+
                if($funcionario>800){
                    echo "O desconto no salário será: ".$funcionario * 0.11;
                }else{
                    echo "Não terá desconto";
                }
                
              ?>
        </section>
    </body>
</html>

