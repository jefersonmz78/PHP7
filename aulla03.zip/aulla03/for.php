<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" type="text/css" href="css/estilo.css" />
        <title>FOR</title>
    </head>
    <body>
        <section class="container">
            <?php
         
           echo "<h2>FOR</h2>";
            /*
             * Loop de repetição - serve para efetuar a repetição de um trecho de um programa, um determinado
             * número de vezes.
             * 
             * FOR - aceita 3 expressões na sua declaração:
             * 
             * Sintaxe:
             * for(inicio;limitador;incremento ou decremento)
             */
           
              for($i=0;$i<=10;$i++){
                  if($i%2!=0){
                      echo $i." :O número eh IMPAR<br/><br/>";
                  }else{
                      echo $i." :O número eh PAR<br/><br/>";
                  }
              }
              
              for($i=0;$i<=10;$i++){
                  echo $i.": George .S. Bezerra<br/><br/>";
              }
              ?>
        </section>
    </body>
</html>

